<?php 
if(isset($_POST['submit'])){
    $email_to = "akkushwaha018@gmail.com"; // this is your Email address
    $from = $_POST['email'];
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $subject = "WE24SEVEN CONTACT US";
    $message = "Name:- ". $name . "\n\n" . "Email:- ". $from. "\n\n" . "Mobile Number" . $mobile . "\n\n" ."Subject:- " . $subject. "\n\n". "Message:- ".$message;

    $headers = "From:" . $from;
    $headers2 = "From:" . $email_to;
    mail($name,$from,$mobile,$subject,$message,$headers);
    header('Location: thank-you.html');
    }
?>